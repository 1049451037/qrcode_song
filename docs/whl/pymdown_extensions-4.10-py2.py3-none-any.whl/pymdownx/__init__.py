"""PyMdown extra extensions."""

from .__version__ import version, version_info  # noqa
